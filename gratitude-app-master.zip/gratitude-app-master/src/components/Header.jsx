import '../css/components.css';
export default function Header() {

    return (
        <div className="header">
            <div className="headerImage">
                <img className="headerImage" src="./images/gratitudeLogoLarge.svg" alt="GratitudeLog">
               
                </img>
            </div>
           
        </div>

    )
}